
import java.io.*;
import java.util.Date;

public class Employee implements java.io.Serializable {
	String lName;
	String fName;
	double salary;
	java.util.Date hireDate;
	String address;
}
